#include "PluginProcessor.h"
#include "PluginEditor.h"

AdaptiveEQEditor::AdaptiveEQEditor (AdaptiveEQProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    setSize (400, 300);
}

AdaptiveEQEditor::~AdaptiveEQEditor()
{
}

void AdaptiveEQEditor::paint (juce::Graphics& g)
{
    g.fillAll (getLookAndFeel().findColour (juce::ResizableWindow::backgroundColourId));

    g.setColour (juce::Colours::white);
    g.setFont (15.0f);
    g.drawFittedText ("AdaptiveEQ", getLocalBounds(), juce::Justification::centred, 1);
}

void AdaptiveEQEditor::resized()
{
}