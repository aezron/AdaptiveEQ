#include "PluginProcessor.h"
#include "PluginEditor.h"

AdaptiveEQProcessor::AdaptiveEQProcessor()
    : AudioProcessor (BusesProperties()
                     .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                     .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      parameters(*this, nullptr, juce::Identifier("AdaptiveEQ"), {
          std::make_unique<juce::AudioParameterBool>("lowEnabled", "Low Enabled", true),
          std::make_unique<juce::AudioParameterFloat>("lowThreshold", "Low Threshold", -60.0f, 0.0f, -24.0f),
          std::make_unique<juce::AudioParameterFloat>("lowRatio", "Low Ratio", 1.0f, 10.0f, 4.0f),
          std::make_unique<juce::AudioParameterFloat>("lowAttack", "Low Attack", 1.0f, 200.0f, 50.0f),
          std::make_unique<juce::AudioParameterFloat>("lowRelease", "Low Release", 10.0f, 1000.0f, 200.0f),
          std::make_unique<juce::AudioParameterFloat>("lowCrossover", "Low Crossover", 50.0f, 1000.0f, 250.0f),
          
          std::make_unique<juce::AudioParameterBool>("midEnabled", "Mid Enabled", true),
          std::make_unique<juce::AudioParameterFloat>("midThreshold", "Mid Threshold", -60.0f, 0.0f, -24.0f),
          std::make_unique<juce::AudioParameterFloat>("midRatio", "Mid Ratio", 1.0f, 10.0f, 4.0f),
          std::make_unique<juce::AudioParameterFloat>("midAttack", "Mid Attack", 1.0f, 200.0f, 50.0f),
          std::make_unique<juce::AudioParameterFloat>("midRelease", "Mid Release", 10.0f, 1000.0f, 200.0f),
          std::make_unique<juce::AudioParameterFloat>("midCrossover", "Mid Crossover", 1000.0f, 10000.0f, 4000.0f),
          
          std::make_unique<juce::AudioParameterBool>("highEnabled", "High Enabled", true),
          std::make_unique<juce::AudioParameterFloat>("highThreshold", "High Threshold", -60.0f, 0.0f, -24.0f),
          std::make_unique<juce::AudioParameterFloat>("highRatio", "High Ratio", 1.0f, 10.0f, 4.0f),
          std::make_unique<juce::AudioParameterFloat>("highAttack", "High Attack", 1.0f, 200.0f, 50.0f),
          std::make_unique<juce::AudioParameterFloat>("highRelease", "High Release", 10.0f, 1000.0f, 200.0f),
          
          std::make_unique<juce::AudioParameterFloat>("inputGain", "Input Gain", -12.0f, 12.0f, 0.0f),
          std::make_unique<juce::AudioParameterFloat>("outputGain", "Output Gain", -12.0f, 12.0f, 0.0f),
          std::make_unique<juce::AudioParameterFloat>("mix", "Mix", 0.0f, 100.0f, 100.0f),
          std::make_unique<juce::AudioParameterFloat>("sensitivity", "Sensitivity", 0.0f, 100.0f, 50.0f)
      }),
      fft(fftOrder),
      window(fftSize, juce::dsp::WindowingFunction<float>::hann)
{
    fftData.resize(fftSize * 2, 0.0f);
    spectrumData.resize(fftSize / 2, 0.0f);
    lowGainReduction.resize(2, 0.0f);
    midGainReduction.resize(2, 0.0f);
    highGainReduction.resize(2, 0.0f);
    lowAttackCoeff.resize(2, 0.0f);
    lowReleaseCoeff.resize(2, 0.0f);
    midAttackCoeff.resize(2, 0.0f);
    midReleaseCoeff.resize(2, 0.0f);
    highAttackCoeff.resize(2, 0.0f);
    highReleaseCoeff.resize(2, 0.0f);
    
    initializePresets();
}

AdaptiveEQProcessor::~AdaptiveEQProcessor()
{
}

void AdaptiveEQProcessor::initializePresets()
{
    factoryPresets.clear();
    
    // Default preset
    factoryPresets.push_back({
        "Default",
        {
            {"lowEnabled", 1.0f}, {"lowThreshold", -24.0f}, {"lowRatio", 4.0f}, {"lowAttack", 50.0f}, {"lowRelease", 200.0f}, {"lowCrossover", 250.0f},
            {"midEnabled", 1.0f}, {"midThreshold", -24.0f}, {"midRatio", 4.0f}, {"midAttack", 50.0f}, {"midRelease", 200.0f}, {"midCrossover", 4000.0f},
            {"highEnabled", 1.0f}, {"highThreshold", -24.0f}, {"highRatio", 4.0f}, {"highAttack", 50.0f}, {"highRelease", 200.0f},
            {"inputGain", 0.0f}, {"outputGain", 0.0f}, {"mix", 100.0f}, {"sensitivity", 50.0f}
        }
    });
    
    // Vocal Clarity preset
    factoryPresets.push_back({
        "Vocal Clarity",
        {
            {"lowEnabled", 1.0f}, {"lowThreshold", -30.0f}, {"lowRatio", 5.0f}, {"lowAttack", 50.0f}, {"lowRelease", 200.0f}, {"lowCrossover", 200.0f},
            {"midEnabled", 1.0f}, {"midThreshold", -20.0f}, {"midRatio", 6.0f}, {"midAttack", 50.0f}, {"midRelease", 200.0f}, {"midCrossover", 5000.0f},
            {"highEnabled", 1.0f}, {"highThreshold", -18.0f}, {"highRatio", 3.0f}, {"highAttack", 50.0f}, {"highRelease", 200.0f},
            {"inputGain", 0.0f}, {"outputGain", 0.0f}, {"mix", 100.0f}, {"sensitivity", 70.0f}
        }
    });
    
    // Remove Mud preset
    factoryPresets.push_back({
        "Remove Mud",
        {
            {"lowEnabled", 1.0f}, {"lowThreshold", -24.0f}, {"lowRatio", 8.0f}, {"lowAttack", 50.0f}, {"lowRelease", 200.0f}, {"lowCrossover", 300.0f},
            {"midEnabled", 1.0f}, {"midThreshold", -30.0f}, {"midRatio", 3.0f}, {"midAttack", 50.0f}, {"midRelease", 200.0f}, {"midCrossover", 2500.0f},
            {"highEnabled", 0.0f}, {"highThreshold", -24.0f}, {"highRatio", 4.0f}, {"highAttack", 50.0f}, {"highRelease", 200.0f},
            {"inputGain", 0.0f}, {"outputGain", 0.0f}, {"mix", 100.0f}, {"sensitivity", 60.0f}
        }
    });
    
    // Tame Brightness preset
    factoryPresets.push_back({
        "Tame Brightness",
        {
            {"lowEnabled", 0.0f}, {"lowThreshold", -24.0f}, {"lowRatio", 4.0f}, {"lowAttack", 50.0f}, {"lowRelease", 200.0f}, {"lowCrossover", 250.0f},
            {"midEnabled", 0.0f}, {"midThreshold", -24.0f}, {"midRatio", 4.0f}, {"midAttack", 50.0f}, {"midRelease", 200.0f}, {"midCrossover", 4000.0f},
            {"highEnabled", 1.0f}, {"highThreshold", -18.0f}, {"highRatio", 6.0f}, {"highAttack", 50.0f}, {"highRelease", 200.0f},
            {"inputGain", 0.0f}, {"outputGain", 0.0f}, {"mix", 100.0f}, {"sensitivity", 80.0f}
        }
    });
    
    // Full Mix preset
    factoryPresets.push_back({
        "Full Mix",
        {
            {"lowEnabled", 1.0f}, {"lowThreshold", -24.0f}, {"lowRatio", 4.0f}, {"lowAttack", 50.0f}, {"lowRelease", 200.0f}, {"lowCrossover", 250.0f},
            {"midEnabled", 1.0f}, {"midThreshold", -20.0f}, {"midRatio", 3.0f}, {"midAttack", 50.0f}, {"midRelease", 200.0f}, {"midCrossover", 3500.0f},
            {"highEnabled", 1.0f}, {"highThreshold", -20.0f}, {"highRatio", 4.0f}, {"highAttack", 50.0f}, {"highRelease", 200.0f},
            {"inputGain", 0.0f}, {"outputGain", 2.0f}, {"mix", 85.0f}, {"sensitivity", 45.0f}
        }
    });
}

void AdaptiveEQProcessor::prepareToPlay (double newSampleRate, int samplesPerBlock)
{
    sampleRate = static_cast<float>(newSampleRate);
    
    juce::dsp::ProcessSpec spec;
    spec.sampleRate = newSampleRate;
    spec.maximumBlockSize = static_cast<juce::uint32>(samplesPerBlock);
    spec.numChannels = static_cast<juce::uint32>(getTotalNumOutputChannels());
    
    lowpassFilter.prepare(spec);
    highpassFilter.prepare(spec);
    bandpassFilter.prepare(spec);
    
    analysisBuffer.setSize(getTotalNumOutputChannels(), fftSize);
    analysisBuffer.clear();
    analysisBufferIndex = 0;
    
    inputGainSmooth.reset(newSampleRate, 0.1);
    outputGainSmooth.reset(newSampleRate, 0.1);
    mixSmooth.reset(newSampleRate, 0.1);
    
    updateFilters();
    
    // Initialize attack/release coefficients
    for (int ch = 0; ch < getTotalNumOutputChannels(); ++ch)
    {
        lowAttackCoeff[ch] = std::exp(-1.0f / (sampleRate * (*parameters.getRawParameterValue("lowAttack") / 1000.0f)));
        lowReleaseCoeff[ch] = std::exp(-1.0f / (sampleRate * (*parameters.getRawParameterValue("lowRelease") / 1000.0f)));
        midAttackCoeff[ch] = std::exp(-1.0f / (sampleRate * (*parameters.getRawParameterValue("midAttack") / 1000.0f)));
        midReleaseCoeff[ch] = std::exp(-1.0f / (sampleRate * (*parameters.getRawParameterValue("midRelease") / 1000.0f)));
        highAttackCoeff[ch] = std::exp(-1.0f / (sampleRate * (*parameters.getRawParameterValue("highAttack") / 1000.0f)));
        highReleaseCoeff[ch] = std::exp(-1.0f / (sampleRate * (*parameters.getRawParameterValue("highRelease") / 1000.0f)));
    }
}

void AdaptiveEQProcessor::updateFilters()
{
    auto lowCrossover = *parameters.getRawParameterValue("lowCrossover");
    auto midCrossover = *parameters.getRawParameterValue("midCrossover");
    
    *lowpassFilter.state = *juce::dsp::IIR::Coefficients<float>::makeLowPass(sampleRate, lowCrossover);
    *highpassFilter.state = *juce::dsp::IIR::Coefficients<float>::makeHighPass(sampleRate, midCrossover);
    *bandpassFilter.state = *juce::dsp::IIR::Coefficients<float>::makeBandPass(sampleRate, (lowCrossover + midCrossover) / 2.0f);
}

void AdaptiveEQProcessor::releaseResources()
{
}

void AdaptiveEQProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    
    auto totalNumInputChannels  = getTotalNumInputChannels();
    auto totalNumOutputChannels = getTotalNumOutputChannels();
    auto numSamples = buffer.getNumSamples();
    
    // Clear unused output channels
    for (auto i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear(i, 0, numSamples);
    
    // Update parameter smoothing
    inputGainSmooth.setTargetValue(juce::Decibels::decibelsToGain(*parameters.getRawParameterValue("inputGain")));
    outputGainSmooth.setTargetValue(juce::Decibels::decibelsToGain(*parameters.getRawParameterValue("outputGain")));
    mixSmooth.setTargetValue(*parameters.getRawParameterValue("mix") / 100.0f);
    
    // Store dry signal for mix
    juce::AudioBuffer<float> dryBuffer;
    dryBuffer.makeCopyOf(buffer);
    
    updateFilters();
    
    // Process each channel
    for (int channel = 0; channel < totalNumInputChannels; ++channel)
    {
        auto* channelData = buffer.getWritePointer(channel);
        
        // Apply input gain
        for (int sample = 0; sample < numSamples; ++sample)
        {
            channelData[sample] *= inputGainSmooth.getNextValue();
        }
        
        // Copy to analysis buffer for FFT
        for (int sample = 0; sample < numSamples; ++sample)
        {
            analysisBuffer.setSample(channel, analysisBufferIndex, channelData[sample]);
            analysisBufferIndex = (analysisBufferIndex + 1) % fftSize;
            
            if (analysisBufferIndex == 0)
            {
                // Perform FFT analysis
                auto* analysisData = analysisBuffer.getReadPointer(channel);
                std::copy(analysisData, analysisData + fftSize, fftData.begin());
                
                window.multiplyWithWindowingTable(fftData.data(), fftSize);
                fft.performFrequencyOnlyForwardTransform(fftData.data());
                
                // Update spectrum data
                for (int i = 0; i < fftSize / 2; ++i)
                {
                    auto real = fftData[i];
                    auto imag = fftData[i + fftSize / 2];
                    spectrumData[i] = std::sqrt(real * real + imag * imag);
                }
            }
        }
        
        // Create separate buffers for each band
        juce::AudioBuffer<float> lowBand, midBand, highBand;
        lowBand.makeCopyOf(buffer);
        midBand.makeCopyOf(buffer);
        highBand.makeCopyOf(buffer);
        
        // Apply band filtering
        juce::dsp::AudioBlock<float> lowBlock(lowBand);
        juce::dsp::AudioBlock<float> midBlock(midBand);
        juce::dsp::AudioBlock<float> highBlock(highBand);
        
        lowpassFilter.process(juce::dsp::ProcessContextReplacing<float>(lowBlock));
        bandpassFilter.process(juce::dsp::ProcessContextReplacing<float>(midBlock));
        highpassFilter.process(juce::dsp::ProcessContextReplacing<float>(highBlock));
        
        // Apply adaptive gain reduction to each band
        auto* lowData = lowBand.getWritePointer(channel);
        auto* midData = midBand.getWritePointer(channel);
        auto* highData = highBand.getWritePointer(channel);
        
        for (int sample = 0; sample < numSamples; ++sample)
        {
            float gainReduction = 1.0f;
            
            // Low band processing
            if (*parameters.getRawParameterValue("lowEnabled"))
            {
                float magnitude = std::abs(lowData[sample]);
                float threshold = juce::Decibels::decibelsToGain(*parameters.getRawParameterValue("lowThreshold"));
                float ratio = *parameters.getRawParameterValue("lowRatio");
                
                if (magnitude > threshold)
                {
                    float excess = magnitude - threshold;
                    gainReduction = threshold + excess / ratio;
                    gainReduction = gainReduction / magnitude;
                    
                    // Apply attack/release
                    float coeff = gainReduction < lowGainReduction[channel] ? lowAttackCoeff[channel] : lowReleaseCoeff[channel];
                    lowGainReduction[channel] = lowGainReduction[channel] * coeff + gainReduction * (1.0f - coeff);
                }
                
                lowData[sample] *= lowGainReduction[channel];
            }
            
            // Mid band processing
            if (*parameters.getRawParameterValue("midEnabled"))
            {
                float magnitude = std::abs(midData[sample]);
                float threshold = juce::Decibels::decibelsToGain(*parameters.getRawParameterValue("midThreshold"));
                float ratio = *parameters.getRawParameterValue("midRatio");
                
                if (magnitude > threshold)
                {
                    float excess = magnitude - threshold;
                    gainReduction = threshold + excess / ratio;
                    gainReduction = gainReduction / magnitude;
                    
                    float coeff = gainReduction < midGainReduction[channel] ? midAttackCoeff[channel] : midReleaseCoeff[channel];
                    midGainReduction[channel] = midGainReduction[channel] * coeff + gainReduction * (1.0f - coeff);
                }
                
                midData[sample] *= midGainReduction[channel];
            }
            
            // High band processing
            if (*parameters.getRawParameterValue("highEnabled"))
            {
                float magnitude = std::abs(highData[sample]);
                float threshold = juce::Decibels::decibelsToGain(*parameters.getRawParameterValue("highThreshold"));
                float ratio = *parameters.getRawParameterValue("highRatio");
                
                if (magnitude > threshold)
                {
                    float excess = magnitude - threshold;
                    gainReduction = threshold + excess / ratio;
                    gainReduction = gainReduction / magnitude;
                    
                    float coeff = gainReduction < highGainReduction[channel] ? highAttackCoeff[channel] : highReleaseCoeff[channel];
                    highGainReduction[channel] = highGainReduction[channel] * coeff + gainReduction * (1.0f - coeff);
                }
                
                highData[sample] *= highGainReduction[channel];
            }
        }
        
        // Sum the bands back together
        for (int sample = 0; sample < numSamples; ++sample)
        {
            channelData[sample] = lowData[sample] + midData[sample] + highData[sample];
        }
        
        // Apply output gain and mix
        auto* dryData = dryBuffer.getReadPointer(channel);
        for (int sample = 0; sample < numSamples; ++sample)
        {
            float outputGain = outputGainSmooth.getNextValue();
            float mix = mixSmooth.getNextValue();
            
            channelData[sample] = channelData[sample] * outputGain * mix + dryData[sample] * (1.0f - mix);
        }
    }
}

bool AdaptiveEQProcessor::hasEditor() const
{
    return true;
}

juce::AudioProcessorEditor* AdaptiveEQProcessor::createEditor()
{
    return new juce::GenericAudioProcessorEditor(*this);
}

void AdaptiveEQProcessor::setCurrentProgram(int index)
{
    if (index >= 0 && index < static_cast<int>(factoryPresets.size()))
    {
        currentPreset = index;
        auto& preset = factoryPresets[index];
        
        for (auto& param : preset.values)
        {
            if (auto* parameter = parameters.getParameter(param.first))
            {
                parameter->setValueNotifyingHost(parameter->convertTo0to1(param.second));
            }
        }
    }
}

const juce::String AdaptiveEQProcessor::getProgramName(int index)
{
    if (index >= 0 && index < static_cast<int>(factoryPresets.size()))
        return factoryPresets[index].name;
    return {};
}

void AdaptiveEQProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void AdaptiveEQProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    
    if (xmlState.get() != nullptr)
        if (xmlState->hasTagName(parameters.state.getType()))
            parameters.replaceState(juce::ValueTree::fromXml(*xmlState));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new AdaptiveEQProcessor();
}