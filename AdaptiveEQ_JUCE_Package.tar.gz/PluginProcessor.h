#pragma once
#include <JuceHeader.h>

class AdaptiveEQProcessor : public juce::AudioProcessor
{
public:
    AdaptiveEQProcessor();
    ~AdaptiveEQProcessor() override;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "AdaptiveEQ"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 5; }
    int getCurrentProgram() override { return currentPreset; }
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    void changeProgramName (int index, const juce::String& newName) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    // Parameters
    juce::AudioProcessorValueTreeState parameters;
    
    // Preset management
    struct Preset {
        juce::String name;
        std::map<juce::String, float> values;
    };
    
    std::vector<Preset> factoryPresets;
    int currentPreset = 0;

private:
    // DSP Components
    static const int fftOrder = 11;
    static const int fftSize = 1 << fftOrder;
    
    juce::dsp::FFT fft;
    juce::dsp::WindowingFunction<float> window;
    std::vector<float> fftData;
    std::vector<float> spectrumData;
    
    // Multi-band processing
    juce::dsp::ProcessorDuplicator<juce::dsp::IIR::Filter<float>, juce::dsp::IIR::Coefficients<float>> lowpassFilter;
    juce::dsp::ProcessorDuplicator<juce::dsp::IIR::Filter<float>, juce::dsp::IIR::Coefficients<float>> highpassFilter;
    juce::dsp::ProcessorDuplicator<juce::dsp::IIR::Filter<float>, juce::dsp::IIR::Coefficients<float>> bandpassFilter;
    
    // Gain reduction processors
    std::vector<float> lowGainReduction, midGainReduction, highGainReduction;
    std::vector<float> lowAttackCoeff, lowReleaseCoeff;
    std::vector<float> midAttackCoeff, midReleaseCoeff;
    std::vector<float> highAttackCoeff, highReleaseCoeff;
    
    // Analysis buffers
    juce::AudioBuffer<float> analysisBuffer;
    int analysisBufferIndex = 0;
    
    // Parameter smoothing
    juce::LinearSmoothedValue<float> inputGainSmooth, outputGainSmooth, mixSmooth;
    
    float sampleRate = 44100.0f;
    void initializePresets();
    void updateFilters();
    float calculateGainReduction(int band, float frequency, float magnitude, float threshold, float ratio);
    float frequencyToMel(float freq);
    float melToFrequency(float mel);
    
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (AdaptiveEQProcessor)
};