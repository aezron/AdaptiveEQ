#!/bin/bash

echo "AdaptiveEQ VST Plugin - Mac/Linux Quick Start"
echo "============================================="
echo

echo "Step 1: Download JUCE Framework"
echo "Visit: https://juce.com/get-juce"
echo "Download JUCE 7.x and install Projucer"
echo

if [[ "$OSTYPE" == "darwin"* ]]; then
    echo "Step 2: Install Xcode (Mac)"
    echo "Download from App Store"
    echo
    
    echo "Step 6: Install Plugin (Mac)"
    echo "AU: ~/Library/Audio/Plug-Ins/Components/"
    echo "VST3: ~/Library/Audio/Plug-Ins/VST3/"
else
    echo "Step 2: Install Build Tools (Linux)"
    echo "sudo apt-get install build-essential cmake"
    echo "sudo apt-get install libasound2-dev libx11-dev libxext-dev libxrandr-dev libxinerama-dev libxcursor-dev libfreetype6-dev libfontconfig1-dev"
    echo
    
    echo "Step 6: Install Plugin (Linux)"
    echo "VST3: ~/.vst3/"
fi

echo "Step 3: Create JUCE Project"
echo "1. Open Projucer"
echo "2. New Project -> Audio Plug-In"
echo "3. Set name: AdaptiveEQ"
echo "4. Enable VST3 format"
echo "5. Set Plugin Code: AdeQ"
echo "6. Set Manufacturer Code: Your 4-letter code"
echo

echo "Step 4: Copy Source Files"
echo "Copy these files to your JUCE project Source folder:"
echo "- PluginProcessor.h"
echo "- PluginProcessor.cpp"
echo "- PluginEditor.h"  
echo "- PluginEditor.cpp"
echo

echo "Step 5: Build"
echo "1. In Projucer: 'Save and Open in IDE'"
if [[ "$OSTYPE" == "darwin"* ]]; then
    echo "2. In Xcode: Product -> Build"
else
    echo "2. In IDE: Build project"
fi
echo "3. Set configuration to Release for final plugin"
echo

echo "Step 7: Test in Ableton"
echo "1. Rescan plugins in Ableton Live preferences"
echo "2. Load AdaptiveEQ from Audio Effects"
echo

echo "Ready to build your AdaptiveEQ plugin!"