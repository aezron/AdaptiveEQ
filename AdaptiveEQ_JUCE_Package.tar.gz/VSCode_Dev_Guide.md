# AdaptiveEQ VST Plugin - VS Code.dev Setup Guide

## Using VS Code.dev (Browser-Based Development)

VS Code.dev is perfect for JUCE plugin development as it provides a full development environment in your browser with GitHub integration.

## Quick Start Steps

### 1. Access VS Code.dev
- Go to [vscode.dev](https://vscode.dev)
- Sign in with your GitHub account
- Create a new repository or open an existing one

### 2. Create Project Structure
```
AdaptiveEQ/
├── Source/
│   ├── PluginProcessor.h
│   ├── PluginProcessor.cpp
│   ├── PluginEditor.h
│   └── PluginEditor.cpp
├── CMakeLists.txt
├── .vscode/
│   ├── settings.json
│   ├── tasks.json
│   └── launch.json
├── .gitmodules
└── README.md
```

### 3. Add JUCE as Git Submodule
Create `.gitmodules` file:
```
[submodule "JUCE"]
    path = JUCE
    url = https://github.com/juce-framework/JUCE.git
    branch = master
```

### 4. Essential Extensions for VS Code.dev
Install these extensions directly in VS Code.dev:
- **C/C++** (Microsoft)
- **CMake Tools** (Microsoft) 
- **GitHub Repositories** (GitHub)
- **GitLens** (GitKraken)

### 5. Browser-Based Development Workflow

#### Option A: GitHub Codespaces (Recommended)
1. Create a new repository on GitHub with your JUCE project
2. Click "Code" → "Create codespace on main"
3. Full Linux environment with build tools available
4. Install dependencies:
   ```bash
   sudo apt-get update
   sudo apt-get install build-essential cmake git
   sudo apt-get install libasound2-dev libx11-dev libxext-dev libxrandr-dev libxinerama-dev libxcursor-dev libfreetype6-dev libfontconfig1-dev
   ```

#### Option B: Local Development with VS Code.dev
1. Use VS Code.dev for code editing and GitHub integration
2. Clone repository locally for building:
   ```bash
   git clone --recursive https://github.com/yourusername/AdaptiveEQ.git
   cd AdaptiveEQ
   cmake -B build -S .
   cmake --build build --config Release
   ```

## GitHub Codespaces Configuration

Create `.devcontainer/devcontainer.json`:
```json
{
    "name": "JUCE Development",
    "image": "mcr.microsoft.com/vscode/devcontainers/cpp:ubuntu-22.04",
    "features": {
        "ghcr.io/devcontainers/features/git:1": {},
        "ghcr.io/devcontainers/features/github-cli:1": {}
    },
    "postCreateCommand": "sudo apt-get update && sudo apt-get install -y libasound2-dev libx11-dev libxext-dev libxrandr-dev libxinerama-dev libxcursor-dev libfreetype6-dev libfontconfig1-dev",
    "customizations": {
        "vscode": {
            "extensions": [
                "ms-vscode.cpptools",
                "ms-vscode.cmake-tools",
                "GitHub.vscode-pull-request-github"
            ]
        }
    },
    "forwardPorts": [8080],
    "remoteUser": "vscode"
}
```

## Building in Codespaces

Once your Codespace is running:

```bash
# Initialize and update JUCE submodule
git submodule init
git submodule update

# Configure CMake
cmake -B build -S . -DCMAKE_BUILD_TYPE=Release

# Build the plugin
cmake --build build --config Release

# List built artifacts
ls -la build/AdaptiveEQ_artefacts/Release/
```

## Testing Your Plugin

### In Codespaces (Standalone Version)
```bash
# Run standalone version for testing
./build/AdaptiveEQ_artefacts/Release/Standalone/AdaptiveEQ
```

### Download Built Plugin
1. Built plugins are in `build/AdaptiveEQ_artefacts/Release/`
2. Download VST3/AU files to your local machine
3. Install in your DAW's plugin directory

## Local Installation Paths

### Windows
```
VST3: C:\Program Files\Common Files\VST3\
```

### Mac
```
AU: ~/Library/Audio/Plug-Ins/Components/
VST3: ~/Library/Audio/Plug-Ins/VST3/
```

### Linux
```
VST3: ~/.vst3/
```

## Complete Workflow Example

1. **Create Repository**
   - Go to GitHub.com
   - Create new repository "AdaptiveEQ"
   - Initialize with README

2. **Open in VS Code.dev**
   - Go to vscode.dev
   - Open your GitHub repository
   - Or use GitHub Codespaces

3. **Add Project Files**
   - Copy all files from this package
   - Commit and push changes

4. **Set Up JUCE**
   ```bash
   git submodule add https://github.com/juce-framework/JUCE.git
   git submodule update --init --recursive
   ```

5. **Build**
   ```bash
   cmake -B build -S .
   cmake --build build --config Release
   ```

6. **Download and Install**
   - Download built VST3 from Codespace
   - Install in Ableton Live plugin folder
   - Rescan plugins in Ableton

## Advantages of VS Code.dev Approach

- **No Local Setup Required**: Everything runs in the browser
- **Consistent Environment**: Same Linux environment across devices
- **GitHub Integration**: Seamless version control
- **Collaborative**: Easy sharing and collaboration
- **Cloud Computing**: Use GitHub's servers for building

## File Management Tips

- **Use Git LFS** for large binary files
- **Ignore Build Artifacts**: Add to `.gitignore`:
  ```
  build/
  *.user
  .DS_Store
  ```
- **Version Control**: Commit source code, not built plugins

## Debugging in Browser Environment

- Use `DBG()` statements for JUCE debugging
- Console output available in Codespace terminal
- Standalone version can run with audio disabled for testing logic

Your AdaptiveEQ plugin can be fully developed, built, and deployed using only a web browser with VS Code.dev and GitHub Codespaces!