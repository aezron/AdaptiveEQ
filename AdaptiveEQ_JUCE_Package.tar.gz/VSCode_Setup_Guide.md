# AdaptiveEQ VST Plugin - VS Code Setup Guide

## Prerequisites

### Windows
1. **Visual Studio Build Tools 2019/2022**
   ```bash
   # Download from: https://visualstudio.microsoft.com/downloads/#build-tools-for-visual-studio-2022
   # Install with "C++ build tools" workload
   ```

2. **CMake**
   ```bash
   # Download from: https://cmake.org/download/
   # Or via chocolatey: choco install cmake
   ```

3. **Git** (if not already installed)
   ```bash
   # Download from: https://git-scm.com/downloads
   ```

### Mac
1. **Xcode Command Line Tools**
   ```bash
   xcode-select --install
   ```

2. **Homebrew** (optional but recommended)
   ```bash
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   brew install cmake
   ```

### Linux (Ubuntu/Debian)
```bash
sudo apt-get update
sudo apt-get install build-essential cmake git
sudo apt-get install libasound2-dev libx11-dev libxext-dev libxrandr-dev libxinerama-dev libxcursor-dev libfreetype6-dev libfontconfig1-dev
```

## VS Code Extensions

Install these essential extensions:
1. **C/C++** (Microsoft)
2. **CMake Tools** (Microsoft)
3. **CMake** (twxs)
4. **JUCE** (SoundDevelopment) - Optional but helpful

## Project Setup

### 1. Download JUCE Framework
```bash
git clone https://github.com/juce-framework/JUCE.git
cd JUCE
git checkout 7.0.9  # Use latest stable version
```

### 2. Create Project Structure
```
AdaptiveEQ/
├── Source/
│   ├── PluginProcessor.h
│   ├── PluginProcessor.cpp
│   ├── PluginEditor.h
│   └── PluginEditor.cpp
├── CMakeLists.txt
├── .vscode/
│   ├── settings.json
│   ├── tasks.json
│   └── launch.json
└── JUCE/  (JUCE framework folder)
```

### 3. Create CMakeLists.txt
```cmake
cmake_minimum_required(VERSION 3.22)

project(AdaptiveEQ VERSION 1.0.0)

# Set C++ standard
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Add JUCE
add_subdirectory(JUCE)

# Create the plugin target
juce_add_plugin(AdaptiveEQ
    COMPANY_NAME "YourCompany"
    IS_SYNTH FALSE
    NEEDS_MIDI_INPUT FALSE
    NEEDS_MIDI_OUTPUT FALSE
    IS_MIDI_EFFECT FALSE
    EDITOR_WANTS_KEYBOARD_FOCUS FALSE
    COPY_PLUGIN_AFTER_BUILD TRUE
    PLUGIN_MANUFACTURER_CODE "Manu"
    PLUGIN_CODE "AdeQ"
    FORMATS AU VST3 Standalone
    PRODUCT_NAME "AdaptiveEQ"
)

# Add source files
target_sources(AdaptiveEQ
    PRIVATE
        Source/PluginProcessor.cpp
        Source/PluginEditor.cpp
)

# Link JUCE modules
target_link_libraries(AdaptiveEQ
    PRIVATE
        juce::juce_audio_utils
        juce::juce_dsp
    PUBLIC
        juce::juce_recommended_config_flags
        juce::juce_recommended_lto_flags
        juce::juce_recommended_warning_flags
)

# Compiler definitions
target_compile_definitions(AdaptiveEQ
    PUBLIC
        JUCE_WEB_BROWSER=0
        JUCE_USE_CURL=0
        JUCE_VST3_CAN_REPLACE_VST2=0
)
```

### 4. VS Code Configuration Files

Create `.vscode/settings.json`:
```json
{
    "cmake.configureOnOpen": true,
    "cmake.buildDirectory": "${workspaceFolder}/build",
    "files.associations": {
        "*.h": "cpp",
        "*.cpp": "cpp"
    },
    "C_Cpp.default.configurationProvider": "ms-vscode.cmake-tools",
    "C_Cpp.default.intelliSenseMode": "windows-msvc-x64"
}
```

Create `.vscode/tasks.json`:
```json
{
    "version": "2.0.0",
    "tasks": [
        {
            "label": "CMake Configure",
            "type": "cmake",
            "command": "configure",
            "group": "build",
            "problemMatcher": []
        },
        {
            "label": "CMake Build",
            "type": "cmake",
            "command": "build",
            "group": {
                "kind": "build",
                "isDefault": true
            },
            "problemMatcher": ["$gcc"]
        },
        {
            "label": "CMake Clean",
            "type": "cmake",
            "command": "clean",
            "group": "build",
            "problemMatcher": []
        }
    ]
}
```

Create `.vscode/launch.json` (for debugging):
```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Debug Standalone",
            "type": "cppvsdbg",
            "request": "launch",
            "program": "${workspaceFolder}/build/AdaptiveEQ_artefacts/Debug/Standalone/AdaptiveEQ.exe",
            "args": [],
            "stopAtEntry": false,
            "cwd": "${workspaceFolder}",
            "environment": [],
            "console": "externalTerminal",
            "preLaunchTask": "CMake Build"
        }
    ]
}
```

## Building the Plugin

### Method 1: Using VS Code Command Palette
1. Open VS Code in your project folder
2. `Ctrl+Shift+P` → "CMake: Configure"
3. `Ctrl+Shift+P` → "CMake: Build"
4. Built plugins will be in `build/AdaptiveEQ_artefacts/`

### Method 2: Using Terminal
```bash
# Configure
cmake -B build -S .

# Build (Debug)
cmake --build build --config Debug

# Build (Release)
cmake --build build --config Release
```

### Method 3: Using VS Code Tasks
1. `Ctrl+Shift+P` → "Tasks: Run Task"
2. Select "CMake Configure" then "CMake Build"

## Plugin Installation

### Windows
```bash
# VST3
copy "build/AdaptiveEQ_artefacts/Release/VST3/AdaptiveEQ.vst3" "C:/Program Files/Common Files/VST3/"
```

### Mac
```bash
# AU
cp -r "build/AdaptiveEQ_artefacts/Release/AU/AdaptiveEQ.component" "~/Library/Audio/Plug-Ins/Components/"

# VST3
cp -r "build/AdaptiveEQ_artefacts/Release/VST3/AdaptiveEQ.vst3" "~/Library/Audio/Plug-Ins/VST3/"
```

### Linux
```bash
# VST3
cp -r "build/AdaptiveEQ_artefacts/Release/VST3/AdaptiveEQ.vst3" "~/.vst3/"
```

## Debugging Tips

1. **Use Standalone Build** for easier debugging
2. **Enable Debug Symbols** in CMake:
   ```cmake
   set(CMAKE_BUILD_TYPE Debug)
   ```
3. **Use JUCE Logger** in your code:
   ```cpp
   DBG("Debug message: " << variableName);
   ```

## Common Issues & Solutions

### Issue: CMake can't find JUCE
**Solution:** Ensure JUCE folder is in your project root or adjust the path in CMakeLists.txt

### Issue: Build errors with MSVC
**Solution:** Install Visual Studio Build Tools with C++ workload

### Issue: Plugin not appearing in DAW
**Solution:** 
- Check plugin was copied to correct folder
- Rescan plugins in your DAW
- Verify plugin format (VST3/AU) is supported

## Advanced: Custom GUI Development

To create a custom interface (like our web prototype), modify `PluginEditor.cpp`:
```cpp
class AdaptiveEQEditor : public juce::AudioProcessorEditor
{
    // Add spectrum analyzer, knobs, etc.
    juce::Slider lowThresholdSlider;
    juce::Slider lowRatioSlider;
    // ... more controls
};
```

## Testing in Ableton Live

1. **Build Release version** of the plugin
2. **Copy to plugin folder** (see installation section)
3. **Restart Ableton Live**
4. **Rescan plugins**: Preferences → Plug-Ins → Rescan
5. **Load plugin**: Audio Effects → AdaptiveEQ

Your AdaptiveEQ plugin is now ready for professional use in Ableton Live!